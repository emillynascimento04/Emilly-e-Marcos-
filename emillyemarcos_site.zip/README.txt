
# Instruções para subir no GitHub Pages

1. Crie um repositório público no GitHub com o nome `emillyemarcos`.
2. Faça upload destes arquivos no repositório (index.html e style.css).
3. Acesse Settings > GitHub Pages e selecione a branch `main` como fonte.
4. Após alguns segundos, seu site estará disponível em:
   https://emillynascimento04.github.io/emillyemarcos
